<?php 
error_reporting(0);
/*
Pelinom İçerik Yönetim Sistemi 
Bilumum Değişkenler Yongası 

Yazan: Ümit TUNÇ
İlk oluşturma tarihi: 01/01/2012 07:44
İlk oluşturma bitiş tarihi: 30/03/2012 19:30
Pelinom 2016 Güncelleme: 22/04/2016 16:20
*/

////////SUNUCU AYARLARI//////////
$sunucu = "localhost";
$veritabani = "truncgilsite_gezidunyasi_pelinom2022";
$kullanici = "truncgilsite_gezidunyasi_pelinom2020";
$parola = "sjgC7p8Lp84!";

include("kobetik/kobetik.php");
include("f.php"); 
oturumAc();

?>
<?php 
ob_clean();
?>
