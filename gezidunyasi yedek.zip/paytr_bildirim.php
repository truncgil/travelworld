<?php include("tema.php");
echo "OK";
?>