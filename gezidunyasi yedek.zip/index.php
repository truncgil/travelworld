<?php error_reporting(E_ALL);
ini_set("display_errors" , 1); 
include("tema.php"); ?>
<?php start(); 

include("view/index.php");
?>

<?php finish(); ?>