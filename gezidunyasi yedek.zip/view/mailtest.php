<?php 
echo mailGonder("umitreva@gmail.com","test","asdasdsadsa");
 ?>
 asd