<div class="col-md-3">
    Doğum Tarihi
    <input type="date" name="<?php e($type) ?>_<?php e($k) ?>_dog_tar" class="form-control" required id="">
</div>
<div class="col-md-3">
    İsim
    <input type="text" name="<?php e($type) ?>_<?php e($k) ?>_adi" class="form-control" required id="">
</div>
<div class="col-md-3">
    Soyadı
    <input type="text" name="<?php e($type) ?>_<?php e($k) ?>_soyadi" class="form-control" required id="">
</div>
<div class="col-md-3">
    TC Kimlik No:
    <input type="number" minlength="11" maxlength="11" name="<?php e($type) ?>_<?php e($k) ?>_tckimlik" class="form-control" required id="">
</div>
