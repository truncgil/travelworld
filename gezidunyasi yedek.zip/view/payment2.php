<form action="" method="post">
    <h1>Seyahat edecek kişi sayısını seçiniz</h1>

    <p>Yetişkin kişi sayısı</p>
    <input type="number" name="" id="" class="form-control">
    

</form>